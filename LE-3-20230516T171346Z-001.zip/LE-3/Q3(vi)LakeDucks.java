class LakeDucks extends Ducks{
    void quack(){
        System.out.println("Lake Ducks Quacks");
    }
    void fly(){
        System.out.println("Lake Duck FLY");
    }
}