abstract class Bharatvanshi{
      public void fight(){
        System.out.println("fighters");
    }
    abstract void obey();
    abstract void kind();

}
