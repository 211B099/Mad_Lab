public class Test implements Testable {
  public void display() {
    System.out.println("Displaying from Test class");
  }
}