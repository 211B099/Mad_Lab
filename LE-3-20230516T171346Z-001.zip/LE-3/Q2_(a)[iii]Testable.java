public interface Testable {
  void display();
}