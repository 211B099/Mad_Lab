public class Pandav extends Bharatvanshi{
    public void obey(){
        System.out.println("Obedience");
    }
    public void kind(){
        System.out.println("kindness");
    }
}