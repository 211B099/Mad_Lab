/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
 public static void main (String args[]){
  Pandav p = new Pandav();
  Bheem b= new Bheem();
  Kauravs k= new Kauravs();
  Vikran v=new Vikran();
  p.fight();
  b.kind();
  b.obey();
  k.fight();
  k.kind();
  k.obey();
  v.fight();
  v.kind();
  v.obey();
 }
}