class Two extends One{
    Two(){
       super(4);
    }
}