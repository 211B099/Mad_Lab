public class Mother{
    int x;
    public void show(){
        System.out.println("Hello World");
    }
}